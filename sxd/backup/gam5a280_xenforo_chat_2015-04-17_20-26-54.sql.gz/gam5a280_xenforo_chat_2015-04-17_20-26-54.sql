#SXD20|20011|50173|50303|2015.04.17 20:26:54|gam5a280_xenforo_chat|utf8|4|5|
#TA ajax_chat_bans`0`16384|ajax_chat_invitations`0`16384|ajax_chat_messages`4`16384|ajax_chat_online`1`16384
#EOH

#	TC`ajax_chat_bans`utf8_bin	;
CREATE TABLE `ajax_chat_bans` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  PRIMARY KEY (`userID`),
  KEY `userName` (`userName`),
  KEY `dateTime` (`dateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`ajax_chat_invitations`utf8_bin	;
CREATE TABLE `ajax_chat_invitations` (
  `userID` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  PRIMARY KEY (`userID`,`channel`),
  KEY `dateTime` (`dateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`ajax_chat_messages`utf8_bin	;
CREATE TABLE `ajax_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `message_condition` (`id`,`channel`,`dateTime`),
  KEY `dateTime` (`dateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`ajax_chat_messages`utf8_bin	;
INSERT INTO `ajax_chat_messages` VALUES 
(46,2147483647,'ChatBot',4,1,'2015-04-16 22:14:54','B�G','/logout administrator Timeout'),
(47,2147483647,'ChatBot',4,1,'2015-04-17 21:11:37','vG�','/login administrator'),
(48,2147483647,'ChatBot',4,1000000001,'2015-04-17 21:11:46','vG�','/who administrator'),
(49,2147483647,'ChatBot',4,1,'2015-04-17 21:11:56','vG�','/roll administrator 1d6 1')	;
#	TC`ajax_chat_online`utf8_bin	;
CREATE TABLE `ajax_chat_online` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) COLLATE utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  PRIMARY KEY (`userID`),
  KEY `userName` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`ajax_chat_online`utf8_bin	;
INSERT INTO `ajax_chat_online` VALUES 
(1,'administrator',3,1,'2015-04-17 21:11:40','vG�')	;
